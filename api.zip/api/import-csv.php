# Deployment auf Shared Webhosting (nur FTP)

## Problem
- Kein Shell-Zugriff
- Kein `composer install` möglich
- Keine Änderungen an `php.ini` möglich

## Lösung: Lokale Installation + FTP-Upload

### Schritt 1: Lokale Vorbereitung (auf deinem PC)

```bash
# Im Projektverzeichnis
cd web-dog-mentality-test

# Composer lokal installieren (Windows)
composer install --no-dev --optimize-autoloader

# Oder falls Composer nicht installiert:
# 1. Download: https://getcomposer.org/download/
# 2. Ausführen: php composer.phar install --no-dev
```

Dies erstellt den `vendor/` Ordner mit PhpSpreadsheet.

### Schritt 2: FTP-Upload

**Hochzuladende Dateien/Ordner:**

```
web-dog-mentality-test/
├── api/                    ← ALLE PHP-Dateien
│   ├── config.php
│   ├── dogs.php
│   ├── batteries.php
│   ├── sessions.php
│   ├── results.php
│   ├── ocean.php
│   ├── ai.php
│   └── import.php
├── database/
│   ├── schema.sql          ← Manuell in phpMyAdmin importieren
│   └── example-data.sql    ← Optional
├── frontend/               ← ALLE Dateien
│   ├── index.html
│   ├── js/
│   │   ├── api.js
│   │   ├── app.js
│   │   └── radar-chart.js
│   └── css/
│       └── styles.css
├── vendor/                 ← WICHTIG: Kompletter Ordner!
│   ├── autoload.php
│   ├── composer/
│   └── phpoffice/          ← PhpSpreadsheet
├── logs/                   ← Leerer Ordner (wird automatisch gefüllt)
├── uploads/                ← Leerer Ordner
└── .env                    ← NICHT .env.example!
```

**WICHTIG:**
- `vendor/` Ordner ist ~5-10 MB groß
- Bei langsamer FTP-Verbindung kann Upload 10-30 Minuten dauern
- **Nicht hochladen**: `.git/`, `.env.example`, `README.md`, `*.md` (optional)

### Schritt 3: Verzeichnisrechte setzen

Via FTP-Client (FileZilla, WinSCP etc.):

```
logs/     → chmod 755 (oder 777 falls 755 nicht funktioniert)
uploads/  → chmod 755 (oder 777)
```

**In FileZilla:**
- Rechtsklick auf Ordner → "Dateiberechtigungen"
- Numerischer Wert: `755`
- Haken bei "In Unterverzeichnisse übernehmen"

### Schritt 4: .env erstellen

**Via FTP-Client:**
1. `.env.example` herunterladen
2. Umbenennen zu `.env`
3. Bearbeiten mit echten Zugangsdaten:

```ini
DB_HOST=localhost
DB_USER=dein_mysql_user
DB_PASS=dein_mysql_passwort
DB_NAME=dein_datenbankname
OPENAI_API_KEY=sk-...

# Falls anderer Port:
# DB_HOST=localhost:3307
```

4. `.env` hochladen (in Root-Verzeichnis)

### Schritt 5: Datenbank importieren

**Via phpMyAdmin:**
1. Einloggen in phpMyAdmin
2. Datenbank erstellen: `CREATE DATABASE dog_mentality CHARACTER SET utf8mb4;`
3. Datenbank auswählen
4. Tab "Importieren"
5. Datei `database/schema.sql` hochladen
6. "Importieren" klicken
7. Optional: `database/example-data.sql` importieren

### Schritt 6: PHP-Settings via .htaccess

Da du `php.ini` nicht ändern kannst, erstelle `.htaccess` im Root:

```apache
# .htaccess für Shared Webhosting

# PHP-Settings (falls der Hoster es erlaubt)
<IfModule mod_php.c>
    php_value upload_max_filesize 10M
    php_value post_max_size 10M
    php_value memory_limit 256M
    php_value max_execution_time 120
    php_value max_input_time 120
</IfModule>

# Falls PHP als CGI läuft (Alternative)
<IfModule mod_fcgid.c>
    FcgidMaxRequestLen 10485760
</IfModule>

# Fehlerbehandlung (Produktion)
php_flag display_errors Off
php_flag log_errors On
php_value error_log logs/php_error.log

# Security
<Files ".env">
    Order allow,deny
    Deny from all
</Files>

# CORS für API (falls Frontend auf anderer Domain)
<IfModule mod_headers.c>
    Header set Access-Control-Allow-Origin "*"
    Header set Access-Control-Allow-Methods "GET, POST, PUT, DELETE, OPTIONS"
    Header set Access-Control-Allow-Headers "Content-Type"
</IfModule>

# URL Rewriting (optional - für schönere URLs)
# RewriteEngine On
# RewriteRule ^api/(.*)$ api/$1 [L]
```

**Upload:** `.htaccess` in Root-Verzeichnis

**WICHTIG:** Nicht alle Hoster erlauben `php_value` in `.htaccess`. Falls Fehler 500:
- Zeilen mit `php_value` auskommentieren oder löschen
- Mit Hoster-Support Limits klären

## Alternative: Excel-Import OHNE PhpSpreadsheet

Falls `vendor/` Upload nicht funktioniert oder zu groß ist, gibt es eine Alternative:

### Option A: CSV-Import statt Excel

<function_calls>
<invoke name="create_file">
<parameter name="content"><?php
/**
 * CSV Import für Testbatterien (Alternative ohne PhpSpreadsheet)
 */

require_once __DIR__ . '/config.php';

header('Content-Type: application/json');

$method = $_SERVER['REQUEST_METHOD'];
$conn = getDbConnection();

try {
    if ($method === 'POST') {
        handleCsvImport($conn);
    } else {
        sendError('Method not allowed', 405);
    }
} catch (Exception $e) {
    logMessage('ERROR', 'import-csv.php: ' . $e->getMessage());
    sendError('Import failed', 500, $e->getMessage());
}

function handleCsvImport($conn) {
    if (!isset($_FILES['file'])) {
        sendError('No file uploaded', 400);
    }
    
    $file = $_FILES['file'];
    
    if ($file['error'] !== UPLOAD_ERR_OK) {
        sendError('Upload error: ' . $file['error'], 400);
    }
    
    // Nur .csv erlaubt
    $fileExtension = strtolower(pathinfo($file['name'], PATHINFO_EXTENSION));
    if ($fileExtension !== 'csv') {
        sendError('Invalid file type. Only .csv allowed', 400);
    }
    
    // CSV parsen
    $handle = fopen($file['tmp_name'], 'r');
    if ($handle === false) {
        sendError('Could not read CSV file', 400);
    }
    
    // Header lesen
    $header = fgetcsv($handle, 1000, ';'); // Semikolon als Separator
    if ($header === false) {
        $header = fgetcsv($handle, 1000, ','); // Oder Komma
        rewind($handle);
        fgetcsv($handle, 1000, ',');
    }
    
    $expectedHeaders = ['Test Nr.', 'Testname', 'OCEAN Dimension', 'Max. Wert', 'Beschreibung'];
    
    // Header validieren (flexibel)
    $validHeader = true;
    foreach ($expectedHeaders as $i => $expected) {
        if (!isset($header[$i]) || trim($header[$i]) !== $expected) {
            $validHeader = false;
            break;
        }
    }
    
    if (!$validHeader) {
        fclose($handle);
        sendError('Invalid CSV format. Expected headers: ' . implode(', ', $expectedHeaders), 400, [
            'found' => $header
        ]);
    }
    
    // Batterie-Name aus Dateinamen
    $batteryName = pathinfo($file['name'], PATHINFO_FILENAME);
    
    // Tests einlesen
    $tests = [];
    $rowNum = 2;
    $validDimensions = ['Offenheit', 'Gewissenhaftigkeit', 'Extraversion', 'Verträglichkeit', 'Neurotizismus'];
    
    while (($row = fgetcsv($handle, 1000, ';')) !== false || ($row = fgetcsv($handle, 1000, ',')) !== false) {
        // Leere Zeile überspringen
        if (empty(trim($row[0]))) {
            continue;
        }
        
        $testNumber = (int)$row[0];
        $testName = trim($row[1]);
        $oceanDimension = trim($row[2]);
        $maxValue = (int)$row[3];
        $description = isset($row[4]) ? trim($row[4]) : '';
        
        // Validierung
        if ($testNumber < 1) {
            fclose($handle);
            sendError("Invalid test number in row {$rowNum}: {$row[0]}", 400);
        }
        
        if (empty($testName)) {
            fclose($handle);
            sendError("Empty test name in row {$rowNum}", 400);
        }
        
        if (!in_array($oceanDimension, $validDimensions)) {
            fclose($handle);
            sendError("Invalid OCEAN dimension in row {$rowNum}: '{$oceanDimension}'. Expected: " . 
                implode(', ', $validDimensions), 400);
        }
        
        if ($maxValue < 1 || $maxValue > 100) {
            fclose($handle);
            sendError("Invalid max_value in row {$rowNum}: {$maxValue}. Must be 1-100", 400);
        }
        
        // Duplikat-Prüfung
        foreach ($tests as $existing) {
            if ($existing['test_number'] === $testNumber) {
                fclose($handle);
                sendError("Duplicate test number: {$testNumber}", 400);
            }
        }
        
        $tests[] = [
            'test_number' => $testNumber,
            'test_name' => $testName,
            'ocean_dimension' => $oceanDimension,
            'max_value' => $maxValue
        ];
        
        $rowNum++;
        
        if ($rowNum > 1000) {
            fclose($handle);
            sendError('Too many rows. Maximum 1000 tests', 400);
        }
    }
    
    fclose($handle);
    
    if (empty($tests)) {
        sendError('No tests found in CSV file', 400);
    }
    
    // In Datenbank importieren
    $conn->begin_transaction();
    
    try {
        $stmt = $conn->prepare("INSERT INTO test_batteries (name) VALUES (?)");
        $stmt->bind_param('s', $batteryName);
        $stmt->execute();
        
        $batteryId = $conn->insert_id;
        
        $stmt = $conn->prepare("
            INSERT INTO battery_tests 
            (battery_id, test_number, test_name, ocean_dimension, max_value)
            VALUES (?, ?, ?, ?, ?)
        ");
        
        foreach ($tests as $test) {
            $stmt->bind_param(
                'iissi',
                $batteryId,
                $test['test_number'],
                $test['test_name'],
                $test['ocean_dimension'],
                $test['max_value']
            );
            $stmt->execute();
        }
        
        $conn->commit();
        
        logMessage('INFO', "Battery imported from CSV: ID={$batteryId}, Name={$batteryName}, Tests=" . count($tests));
        
        sendResponse([
            'message' => 'Battery imported successfully',
            'battery_id' => $batteryId,
            'battery_name' => $batteryName,
            'test_count' => count($tests)
        ], 201);
        
    } catch (Exception $e) {
        $conn->rollback();
        throw $e;
    }
}
