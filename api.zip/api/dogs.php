<?php
/**
 * API Endpoint: Dogs (Stammdaten)
 * 
 * GET    /api/dogs.php          - Alle Hunde abrufen
 * GET    /api/dogs.php?id=1     - Einzelnen Hund abrufen
 * POST   /api/dogs.php          - Neuen Hund erstellen
 * PUT    /api/dogs.php?id=1     - Hund aktualisieren
 * DELETE /api/dogs.php?id=1     - Hund löschen
 */

require_once 'config.php';

$method = $_SERVER['REQUEST_METHOD'];
$conn = getDbConnection();

// GET: Hunde abrufen
if ($method === 'GET') {
    if (isset($_GET['id'])) {
        // Einzelnen Hund
        $id = validateInteger($_GET['id'], 1, null, 'Dog ID');
        
        $stmt = $conn->prepare("SELECT * FROM dogs WHERE id = ?");
        $stmt->bind_param("i", $id);
        $stmt->execute();
        $result = $stmt->get_result();
        
        if ($dog = $result->fetch_assoc()) {
            sendResponse($dog);
        } else {
            sendError('Hund nicht gefunden', 404);
        }
        
    } else {
        // Alle Hunde mit optionaler Suche
        $search = isset($_GET['search']) ? sanitizeString($_GET['search']) : '';
        
        if ($search) {
            $searchParam = "%$search%";
            $stmt = $conn->prepare("
                SELECT * FROM dogs 
                WHERE dog_name LIKE ? 
                   OR owner_name LIKE ? 
                   OR breed LIKE ?
                ORDER BY dog_name ASC
            ");
            $stmt->bind_param("sss", $searchParam, $searchParam, $searchParam);
        } else {
            $stmt = $conn->prepare("SELECT * FROM dogs ORDER BY created_at DESC");
        }
        
        $stmt->execute();
        $result = $stmt->get_result();
        
        $dogs = [];
        while ($row = $result->fetch_assoc()) {
            $dogs[] = $row;
        }
        
        sendResponse([
            'total' => count($dogs),
            'dogs' => $dogs
        ]);
    }
}

// POST: Neuen Hund erstellen
elseif ($method === 'POST') {
    $data = getJsonInput();
    
    // Validierung
    validateRequired($data, ['owner_name', 'dog_name', 'age_years', 'gender']);
    
    $owner_name = sanitizeString($data['owner_name']);
    $dog_name = sanitizeString($data['dog_name']);
    $breed = sanitizeString($data['breed'] ?? '');
    $age_years = validateInteger($data['age_years'], 0, 20, 'Alter (Jahre)');
    $age_months = validateInteger($data['age_months'] ?? 0, 0, 11, 'Alter (Monate)');
    $gender = validateEnum($data['gender'], ['Rüde', 'Hündin'], 'Geschlecht');
    $neutered = isset($data['neutered']) ? (bool)$data['neutered'] : false;
    $intended_use = sanitizeString($data['intended_use'] ?? '');
    
    // Validierung: Alter mindestens 1 Monat
    if ($age_years === 0 && $age_months === 0) {
        sendError('Alter muss mindestens 1 Monat betragen');
    }
    
    // Insert
    $stmt = $conn->prepare("
        INSERT INTO dogs 
        (owner_name, dog_name, breed, age_years, age_months, gender, neutered, intended_use)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?)
    ");
    
    $stmt->bind_param(
        "sssiisis",
        $owner_name, $dog_name, $breed, $age_years, $age_months, 
        $gender, $neutered, $intended_use
    );
    
    if ($stmt->execute()) {
        $newId = $conn->insert_id;
        
        // Neu erstellten Hund zurückgeben
        $stmt = $conn->prepare("SELECT * FROM dogs WHERE id = ?");
        $stmt->bind_param("i", $newId);
        $stmt->execute();
        $result = $stmt->get_result();
        $newDog = $result->fetch_assoc();
        
        logMessage("Neuer Hund erstellt: ID $newId, Name: $dog_name");
        sendResponse($newDog, 201);
        
    } else {
        sendError('Fehler beim Erstellen des Hundes', 500, $stmt->error);
    }
}

// PUT: Hund aktualisieren
elseif ($method === 'PUT') {
    if (!isset($_GET['id'])) {
        sendError('Dog ID erforderlich');
    }
    
    $id = validateInteger($_GET['id'], 1, null, 'Dog ID');
    $data = getJsonInput();
    
    // Prüfen ob Hund existiert
    $stmt = $conn->prepare("SELECT id FROM dogs WHERE id = ?");
    $stmt->bind_param("i", $id);
    $stmt->execute();
    if ($stmt->get_result()->num_rows === 0) {
        sendError('Hund nicht gefunden', 404);
    }
    
    // Validierung
    validateRequired($data, ['owner_name', 'dog_name', 'age_years', 'gender']);
    
    $owner_name = sanitizeString($data['owner_name']);
    $dog_name = sanitizeString($data['dog_name']);
    $breed = sanitizeString($data['breed'] ?? '');
    $age_years = validateInteger($data['age_years'], 0, 20, 'Alter (Jahre)');
    $age_months = validateInteger($data['age_months'] ?? 0, 0, 11, 'Alter (Monate)');
    $gender = validateEnum($data['gender'], ['Rüde', 'Hündin'], 'Geschlecht');
    $neutered = isset($data['neutered']) ? (bool)$data['neutered'] : false;
    $intended_use = sanitizeString($data['intended_use'] ?? '');
    
    // Validierung: Alter mindestens 1 Monat
    if ($age_years === 0 && $age_months === 0) {
        sendError('Alter muss mindestens 1 Monat betragen');
    }
    
    // Update
    $stmt = $conn->prepare("
        UPDATE dogs SET
            owner_name = ?,
            dog_name = ?,
            breed = ?,
            age_years = ?,
            age_months = ?,
            gender = ?,
            neutered = ?,
            intended_use = ?
        WHERE id = ?
    ");
    
    $stmt->bind_param(
        "sssiisisi",
        $owner_name, $dog_name, $breed, $age_years, $age_months,
        $gender, $neutered, $intended_use, $id
    );
    
    if ($stmt->execute()) {
        // Aktualisierten Hund zurückgeben
        $stmt = $conn->prepare("SELECT * FROM dogs WHERE id = ?");
        $stmt->bind_param("i", $id);
        $stmt->execute();
        $result = $stmt->get_result();
        $updatedDog = $result->fetch_assoc();
        
        logMessage("Hund aktualisiert: ID $id, Name: $dog_name");
        sendResponse($updatedDog);
        
    } else {
        sendError('Fehler beim Aktualisieren des Hundes', 500, $stmt->error);
    }
}

// DELETE: Hund löschen
elseif ($method === 'DELETE') {
    if (!isset($_GET['id'])) {
        sendError('Dog ID erforderlich');
    }
    
    $id = validateInteger($_GET['id'], 1, null, 'Dog ID');
    
    // Prüfen ob Hund existiert
    $stmt = $conn->prepare("SELECT dog_name FROM dogs WHERE id = ?");
    $stmt->bind_param("i", $id);
    $stmt->execute();
    $result = $stmt->get_result();
    
    if ($result->num_rows === 0) {
        sendError('Hund nicht gefunden', 404);
    }
    
    $dog = $result->fetch_assoc();
    $dogName = $dog['dog_name'];
    
    // Löschen (CASCADE löscht automatisch zugehörige Sessions)
    $stmt = $conn->prepare("DELETE FROM dogs WHERE id = ?");
    $stmt->bind_param("i", $id);
    
    if ($stmt->execute()) {
        logMessage("Hund gelöscht: ID $id, Name: $dogName");
        sendResponse([
            'message' => 'Hund erfolgreich gelöscht',
            'id' => $id,
            'deleted_dog' => $dogName
        ]);
    } else {
        sendError('Fehler beim Löschen des Hundes', 500, $stmt->error);
    }
}

else {
    sendError('Methode nicht erlaubt', 405);
}

?>
