<?php
/**
 * API Endpoint: Test Sessions
 * 
 * GET    /api/sessions.php           - Alle Sessions abrufen
 * GET    /api/sessions.php?id=1      - Einzelne Session mit Details
 * POST   /api/sessions.php           - Neue Session erstellen
 * PUT    /api/sessions.php?id=1      - Session aktualisieren
 * DELETE /api/sessions.php?id=1      - Session löschen
 */

require_once 'config.php';

$method = $_SERVER['REQUEST_METHOD'];
$conn = getDbConnection();

// GET: Sessions abrufen
if ($method === 'GET') {
    if (isset($_GET['id'])) {
        // Einzelne Session mit allen Details
        $id = validateInteger($_GET['id'], 1, null, 'Session ID');
        
        // Session-Grunddaten mit Dog + Battery Info
        $stmt = $conn->prepare("SELECT * FROM v_session_overview WHERE session_id = ?");
        $stmt->bind_param("i", $id);
        $stmt->execute();
        $result = $stmt->get_result();
        
        if ($session = $result->fetch_assoc()) {
            // JSON-Felder dekodieren
            if ($session['ideal_profile']) {
                $session['ideal_profile'] = json_decode($session['ideal_profile'], true);
            }
            if ($session['owner_profile']) {
                $session['owner_profile'] = json_decode($session['owner_profile'], true);
            }
            
            // Test-Ergebnisse laden
            $stmt = $conn->prepare("
                SELECT tr.id, tr.test_number, tr.score, tr.notes,
                       bt.name as test_name, bt.ocean_dimension
                FROM test_results tr
                LEFT JOIN test_sessions ts ON tr.session_id = ts.id
                LEFT JOIN battery_tests bt ON ts.battery_id = bt.battery_id 
                    AND tr.test_number = bt.test_number
                WHERE tr.session_id = ?
                ORDER BY tr.test_number
            ");
            $stmt->bind_param("i", $id);
            $stmt->execute();
            $results = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);
            
            $session['results'] = $results;
            
            sendResponse($session);
        } else {
            sendError('Session nicht gefunden', 404);
        }
        
    } else {
        // Alle Sessions (Übersicht)
        $dogId = isset($_GET['dog_id']) ? validateInteger($_GET['dog_id'], 1) : null;
        
        if ($dogId) {
            $stmt = $conn->prepare("SELECT * FROM v_session_overview WHERE dog_id = ? ORDER BY session_date DESC");
            $stmt->bind_param("i", $dogId);
        } else {
            $stmt = $conn->prepare("SELECT * FROM v_session_overview ORDER BY session_date DESC");
        }
        
        $stmt->execute();
        $result = $stmt->get_result();
        
        $sessions = [];
        while ($row = $result->fetch_assoc()) {
            // JSON-Felder dekodieren
            if ($row['ideal_profile']) {
                $row['ideal_profile'] = json_decode($row['ideal_profile'], true);
            }
            if ($row['owner_profile']) {
                $row['owner_profile'] = json_decode($row['owner_profile'], true);
            }
            $sessions[] = $row;
        }
        
        sendResponse([
            'total' => count($sessions),
            'sessions' => $sessions
        ]);
    }
}

// POST: Neue Session erstellen
elseif ($method === 'POST') {
    $data = getJsonInput();
    
    // Validierung
    validateRequired($data, ['dog_id', 'battery_id']);
    
    $dog_id = validateInteger($data['dog_id'], 1, null, 'Dog ID');
    $battery_id = validateInteger($data['battery_id'], 1, null, 'Battery ID');
    $session_notes = sanitizeString($data['session_notes'] ?? '');
    
    // Optional: Profile validieren falls vorhanden
    $ideal_profile = null;
    $owner_profile = null;
    $ai_assessment = null;
    
    if (isset($data['ideal_profile']) && !empty($data['ideal_profile'])) {
        $ideal_profile = json_encode(validateOceanProfile($data['ideal_profile']));
    }
    
    if (isset($data['owner_profile']) && !empty($data['owner_profile'])) {
        $owner_profile = json_encode(validateOceanProfile($data['owner_profile']));
    }
    
    if (isset($data['ai_assessment'])) {
        $ai_assessment = sanitizeString($data['ai_assessment']);
    }
    
    // Prüfen ob Dog und Battery existieren
    $stmt = $conn->prepare("SELECT id FROM dogs WHERE id = ?");
    $stmt->bind_param("i", $dog_id);
    $stmt->execute();
    if ($stmt->get_result()->num_rows === 0) {
        sendError('Hund nicht gefunden', 404);
    }
    
    $stmt = $conn->prepare("SELECT id FROM test_batteries WHERE id = ?");
    $stmt->bind_param("i", $battery_id);
    $stmt->execute();
    if ($stmt->get_result()->num_rows === 0) {
        sendError('Testbatterie nicht gefunden', 404);
    }
    
    // Insert
    $stmt = $conn->prepare("
        INSERT INTO test_sessions 
        (dog_id, battery_id, session_notes, ideal_profile, owner_profile, ai_assessment)
        VALUES (?, ?, ?, ?, ?, ?)
    ");
    
    $stmt->bind_param(
        "iissss",
        $dog_id, $battery_id, $session_notes,
        $ideal_profile, $owner_profile, $ai_assessment
    );
    
    if ($stmt->execute()) {
        $newId = $conn->insert_id;
        
        // Neu erstellte Session zurückgeben
        $stmt = $conn->prepare("SELECT * FROM v_session_overview WHERE session_id = ?");
        $stmt->bind_param("i", $newId);
        $stmt->execute();
        $result = $stmt->get_result();
        $newSession = $result->fetch_assoc();
        
        // JSON dekodieren
        if ($newSession['ideal_profile']) {
            $newSession['ideal_profile'] = json_decode($newSession['ideal_profile'], true);
        }
        if ($newSession['owner_profile']) {
            $newSession['owner_profile'] = json_decode($newSession['owner_profile'], true);
        }
        $newSession['results'] = [];
        
        logMessage("Neue Session erstellt: ID $newId, Dog ID: $dog_id");
        sendResponse($newSession, 201);
        
    } else {
        sendError('Fehler beim Erstellen der Session', 500, $stmt->error);
    }
}

// PUT: Session aktualisieren
elseif ($method === 'PUT') {
    if (!isset($_GET['id'])) {
        sendError('Session ID erforderlich');
    }
    
    $id = validateInteger($_GET['id'], 1, null, 'Session ID');
    $data = getJsonInput();
    
    // Prüfen ob Session existiert
    $stmt = $conn->prepare("SELECT id FROM test_sessions WHERE id = ?");
    $stmt->bind_param("i", $id);
    $stmt->execute();
    if ($stmt->get_result()->num_rows === 0) {
        sendError('Session nicht gefunden', 404);
    }
    
    // Felder aktualisieren (nur die übergebenen)
    $updates = [];
    $params = [];
    $types = "";
    
    if (isset($data['session_notes'])) {
        $updates[] = "session_notes = ?";
        $params[] = sanitizeString($data['session_notes']);
        $types .= "s";
    }
    
    if (isset($data['ideal_profile'])) {
        $updates[] = "ideal_profile = ?";
        $params[] = json_encode(validateOceanProfile($data['ideal_profile']));
        $types .= "s";
    }
    
    if (isset($data['owner_profile'])) {
        $updates[] = "owner_profile = ?";
        $params[] = json_encode(validateOceanProfile($data['owner_profile']));
        $types .= "s";
    }
    
    if (isset($data['ai_assessment'])) {
        $updates[] = "ai_assessment = ?";
        $params[] = sanitizeString($data['ai_assessment']);
        $types .= "s";
    }
    
    if (empty($updates)) {
        sendError('Keine Felder zum Aktualisieren angegeben');
    }
    
    // Update ausführen
    $sql = "UPDATE test_sessions SET " . implode(", ", $updates) . " WHERE id = ?";
    $params[] = $id;
    $types .= "i";
    
    $stmt = $conn->prepare($sql);
    $stmt->bind_param($types, ...$params);
    
    if ($stmt->execute()) {
        // Aktualisierte Session zurückgeben
        $stmt = $conn->prepare("SELECT * FROM v_session_overview WHERE session_id = ?");
        $stmt->bind_param("i", $id);
        $stmt->execute();
        $result = $stmt->get_result();
        $updatedSession = $result->fetch_assoc();
        
        // JSON dekodieren
        if ($updatedSession['ideal_profile']) {
            $updatedSession['ideal_profile'] = json_decode($updatedSession['ideal_profile'], true);
        }
        if ($updatedSession['owner_profile']) {
            $updatedSession['owner_profile'] = json_decode($updatedSession['owner_profile'], true);
        }
        
        logMessage("Session aktualisiert: ID $id");
        sendResponse($updatedSession);
        
    } else {
        sendError('Fehler beim Aktualisieren der Session', 500, $stmt->error);
    }
}

// DELETE: Session löschen
elseif ($method === 'DELETE') {
    if (!isset($_GET['id'])) {
        sendError('Session ID erforderlich');
    }
    
    $id = validateInteger($_GET['id'], 1, null, 'Session ID');
    
    // Prüfen ob Session existiert
    $stmt = $conn->prepare("SELECT session_date FROM test_sessions WHERE id = ?");
    $stmt->bind_param("i", $id);
    $stmt->execute();
    $result = $stmt->get_result();
    
    if ($result->num_rows === 0) {
        sendError('Session nicht gefunden', 404);
    }
    
    $session = $result->fetch_assoc();
    
    // Löschen (CASCADE löscht automatisch zugehörige Results)
    $stmt = $conn->prepare("DELETE FROM test_sessions WHERE id = ?");
    $stmt->bind_param("i", $id);
    
    if ($stmt->execute()) {
        logMessage("Session gelöscht: ID $id");
        sendResponse([
            'message' => 'Session erfolgreich gelöscht',
            'id' => $id
        ]);
    } else {
        sendError('Fehler beim Löschen der Session', 500, $stmt->error);
    }
}

else {
    sendError('Methode nicht erlaubt', 405);
}

?>
