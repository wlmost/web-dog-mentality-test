/**
 * Main Application Logic
 */

// Global State
const state = {
    currentTab: 'dogs',
    currentDog: null,
    currentSession: null,
    currentBattery: null,
    dogs: [],
    sessions: [],
    batteries: [],
    oceanChart: null
};

// ===== INITIALIZATION =====
document.addEventListener('DOMContentLoaded', () => {
    initializeApp();
});

async function initializeApp() {
    setupEventListeners();
    await loadDogs();
    switchTab('dogs');
}

// ===== EVENT LISTENERS =====
function setupEventListeners() {
    // Tab Navigation
    document.querySelectorAll('[data-tab]').forEach(link => {
        link.addEventListener('click', (e) => {
            e.preventDefault();
            const tab = e.currentTarget.dataset.tab;
            switchTab(tab);
        });
    });

    // Hunde
    document.getElementById('btn-new-dog').addEventListener('click', () => openDogModal());
    document.getElementById('btn-save-dog').addEventListener('click', saveDog);
    document.getElementById('search-dogs').addEventListener('input', debounce(searchDogs, 300));

    // Sessions
    document.getElementById('btn-new-session').addEventListener('click', createNewSession);
    document.getElementById('btn-back-sessions').addEventListener('click', () => {
        document.getElementById('session-detail').classList.add('d-none');
        document.getElementById('sessions-list').classList.remove('d-none');
    });
    document.getElementById('btn-save-session').addEventListener('click', saveSession);

    // Analysis
    document.getElementById('select-analysis-session').addEventListener('change', loadAnalysis);
    document.getElementById('btn-generate-ideal').addEventListener('click', generateIdealProfile);
    document.getElementById('btn-save-owner-profile').addEventListener('click', saveOwnerProfile);
    document.getElementById('btn-generate-assessment').addEventListener('click', generateAssessment);
}

// ===== TAB SWITCHING =====
function switchTab(tabName) {
    state.currentTab = tabName;

    // Update nav
    document.querySelectorAll('.nav-link').forEach(link => {
        link.classList.remove('active');
        if (link.dataset.tab === tabName) {
            link.classList.add('active');
        }
    });

    // Update content
    document.querySelectorAll('.tab-content').forEach(content => {
        content.classList.remove('active');
    });
    document.getElementById(`tab-${tabName}`).classList.add('active');

    // Load data for tab
    if (tabName === 'dogs') {
        loadDogs();
    } else if (tabName === 'sessions') {
        loadSessions();
    } else if (tabName === 'batteries') {
        loadBatteriesList();
    } else if (tabName === 'analysis') {
        loadAnalysisSessionList();
    }
}

// ===== DOGS =====
async function loadDogs(search = '') {
    showLoading();
    try {
        const data = await api.getDogs(search);
        state.dogs = data.dogs;
        renderDogs(data.dogs);
    } catch (error) {
        showToast('Fehler beim Laden der Hunde', 'danger');
    } finally {
        hideLoading();
    }
}

function renderDogs(dogs) {
    const container = document.getElementById('dogs-list');
    
    if (dogs.length === 0) {
        container.innerHTML = `
            <div class="col-12">
                <div class="alert alert-info">
                    <i class="bi bi-info-circle"></i> Keine Hunde gefunden. Klicken Sie auf "Neuer Hund" um anzufangen.
                </div>
            </div>
        `;
        return;
    }

    container.innerHTML = dogs.map(dog => `
        <div class="col-lg-4 col-md-6">
            <div class="card dog-card h-100">
                <div class="card-body">
                    <div class="d-flex justify-content-between align-items-start mb-2">
                        <h5 class="card-title mb-0">
                            <i class="bi bi-${dog.gender === 'Rüde' ? 'gender-male text-primary' : 'gender-female text-danger'}"></i>
                            ${escapeHtml(dog.dog_name)}
                        </h5>
                        <div class="btn-group btn-group-sm">
                            <button class="btn btn-outline-primary" onclick="editDog(${dog.id})">
                                <i class="bi bi-pencil"></i>
                            </button>
                            <button class="btn btn-outline-danger" onclick="deleteDog(${dog.id}, '${escapeHtml(dog.dog_name)}')">
                                <i class="bi bi-trash"></i>
                            </button>
                        </div>
                    </div>
                    <p class="text-muted mb-2">
                        <i class="bi bi-person"></i> ${escapeHtml(dog.owner_name)}
                    </p>
                    <div class="dog-meta">
                        ${dog.breed ? `<span class="badge bg-secondary">${escapeHtml(dog.breed)}</span>` : ''}
                        <span class="badge bg-info">${formatAge(dog.age_years, dog.age_months)}</span>
                        ${dog.neutered ? '<span class="badge bg-warning">Kastriert</span>' : ''}
                    </div>
                    ${dog.intended_use ? `<p class="mt-2 mb-0"><small><i class="bi bi-star"></i> ${escapeHtml(dog.intended_use)}</small></p>` : ''}
                </div>
                <div class="card-footer">
                    <button class="btn btn-success w-100" onclick="viewDogSessions(${dog.id}, '${escapeHtml(dog.dog_name)}')">
                        <i class="bi bi-clipboard-check"></i> Sessions anzeigen
                    </button>
                </div>
            </div>
        </div>
    `).join('');
}

async function searchDogs(e) {
    await loadDogs(e.target.value);
}

function openDogModal(dog = null) {
    const modal = new bootstrap.Modal(document.getElementById('modal-dog'));
    const form = document.getElementById('form-dog');
    form.reset();

    if (dog) {
        document.getElementById('modal-dog-title').textContent = 'Hund bearbeiten';
        document.getElementById('dog-id').value = dog.id;
        document.getElementById('dog-owner-name').value = dog.owner_name;
        document.getElementById('dog-name').value = dog.dog_name;
        document.getElementById('dog-breed').value = dog.breed || '';
        document.getElementById('dog-age-years').value = dog.age_years;
        document.getElementById('dog-age-months').value = dog.age_months;
        document.getElementById('dog-gender').value = dog.gender;
        document.getElementById('dog-neutered').checked = dog.neutered;
        document.getElementById('dog-intended-use').value = dog.intended_use || '';
    } else {
        document.getElementById('modal-dog-title').textContent = 'Neuer Hund';
        document.getElementById('dog-id').value = '';
    }

    modal.show();
}

async function editDog(id) {
    showLoading();
    try {
        const dog = await api.getDog(id);
        openDogModal(dog);
    } catch (error) {
        showToast('Fehler beim Laden des Hundes', 'danger');
    } finally {
        hideLoading();
    }
}

async function saveDog() {
    const form = document.getElementById('form-dog');
    if (!form.checkValidity()) {
        form.reportValidity();
        return;
    }

    const dogData = {
        owner_name: document.getElementById('dog-owner-name').value,
        dog_name: document.getElementById('dog-name').value,
        breed: document.getElementById('dog-breed').value,
        age_years: parseInt(document.getElementById('dog-age-years').value),
        age_months: parseInt(document.getElementById('dog-age-months').value),
        gender: document.getElementById('dog-gender').value,
        neutered: document.getElementById('dog-neutered').checked,
        intended_use: document.getElementById('dog-intended-use').value
    };

    const id = document.getElementById('dog-id').value;

    showLoading();
    try {
        if (id) {
            await api.updateDog(id, dogData);
            showToast('Hund aktualisiert', 'success');
        } else {
            await api.createDog(dogData);
            showToast('Hund erstellt', 'success');
        }

        bootstrap.Modal.getInstance(document.getElementById('modal-dog')).hide();
        await loadDogs();
    } catch (error) {
        showToast(error.message, 'danger');
    } finally {
        hideLoading();
    }
}

async function deleteDog(id, name) {
    if (!confirm(`Hund "${name}" wirklich löschen? Alle zugehörigen Sessions werden ebenfalls gelöscht!`)) {
        return;
    }

    showLoading();
    try {
        await api.deleteDog(id);
        showToast('Hund gelöscht', 'success');
        await loadDogs();
    } catch (error) {
        showToast(error.message, 'danger');
    } finally {
        hideLoading();
    }
}

function viewDogSessions(dogId, dogName) {
    state.currentDog = { id: dogId, name: dogName };
    switchTab('sessions');
}

// ===== SESSIONS =====
async function loadSessions() {
    const dogId = state.currentDog?.id;
    
    if (!dogId) {
        document.getElementById('sessions-list').innerHTML = `
            <div class="alert alert-info">
                <i class="bi bi-info-circle"></i> Bitte wählen Sie zuerst einen Hund im Tab "Hunde" aus.
            </div>
        `;
        document.getElementById('btn-new-session').disabled = true;
        return;
    }

    document.getElementById('btn-new-session').disabled = false;

    showLoading();
    try {
        const data = await api.getSessions(dogId);
        state.sessions = data.sessions;
        renderSessions(data.sessions);
    } catch (error) {
        showToast('Fehler beim Laden der Sessions', 'danger');
    } finally {
        hideLoading();
    }
}

function renderSessions(sessions) {
    const container = document.getElementById('sessions-list');

    if (sessions.length === 0) {
        container.innerHTML = `
            <div class="alert alert-info">
                <i class="bi bi-info-circle"></i> Noch keine Sessions vorhanden. Klicken Sie auf "Neue Session" um zu beginnen.
            </div>
        `;
        return;
    }

    container.innerHTML = `
        <div class="list-group">
            ${sessions.map(session => `
                <a href="#" class="list-group-item list-group-item-action" onclick="loadSessionDetail(${session.session_id}); return false;">
                    <div class="d-flex w-100 justify-content-between">
                        <h5 class="mb-1">${escapeHtml(session.battery_name)}</h5>
                        <small>${formatDate(session.session_date)}</small>
                    </div>
                    <p class="mb-1"><strong>${escapeHtml(session.dog_name)}</strong> (${escapeHtml(session.breed || 'Keine Rasse')})</p>
                    <div class="d-flex justify-content-between align-items-center">
                        <small>Tests abgeschlossen: ${session.completed_tests}</small>
                        <span class="badge bg-primary">${session.completed_tests > 0 ? 'In Bearbeitung' : 'Neu'}</span>
                    </div>
                </a>
            `).join('')}
        </div>
    `;
}

async function createNewSession() {
    // Batterien laden
    showLoading();
    try {
        const data = await api.getBatteries();
        
        if (data.batteries.length === 0) {
            showToast('Keine Testbatterien vorhanden. Bitte erst eine Batterie anlegen.', 'warning');
            hideLoading();
            return;
        }
        
        // Modal zur Batterieauswahl
        let batteryOptions = data.batteries.map(b => 
            `<option value="${b.id}">${escapeHtml(b.name)} (${b.test_count} Tests)</option>`
        ).join('');
        
        const result = await showBatterySelectionModal(batteryOptions);
        
        if (result) {
            const sessionData = {
                dog_id: state.currentDog.id,
                battery_id: parseInt(result),
                session_notes: ''
            };
            
            const newSession = await api.createSession(sessionData);
            showToast('Session erstellt', 'success');
            await loadSessionDetail(newSession.session_id);
        }
    } catch (error) {
        showToast(error.message, 'danger');
    } finally {
        hideLoading();
    }
}

async function showBatterySelectionModal(options) {
    return new Promise((resolve) => {
        const modal = document.createElement('div');
        modal.className = 'modal fade';
        modal.innerHTML = `
            <div class="modal-dialog">
                <div class="modal-content">
                    <div class="modal-header">
                        <h5 class="modal-title">Testbatterie auswählen</h5>
                        <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                    </div>
                    <div class="modal-body">
                        <select id="battery-select" class="form-select form-select-lg">
                            ${options}
                        </select>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Abbrechen</button>
                        <button type="button" class="btn btn-primary" id="btn-select-battery">Auswählen</button>
                    </div>
                </div>
            </div>
        `;
        
        document.body.appendChild(modal);
        const bsModal = new bootstrap.Modal(modal);
        
        modal.querySelector('#btn-select-battery').addEventListener('click', () => {
            const value = modal.querySelector('#battery-select').value;
            bsModal.hide();
            resolve(value);
        });
        
        modal.addEventListener('hidden.bs.modal', () => {
            modal.remove();
            resolve(null);
        });
        
        bsModal.show();
    });
}

async function loadSessionDetail(sessionId) {
    showLoading();
    try {
        const session = await api.getSession(sessionId);
        state.currentSession = session;
        renderSessionDetail(session);

        document.getElementById('sessions-list').classList.add('d-none');
        document.getElementById('session-detail').classList.remove('d-none');
    } catch (error) {
        showToast('Fehler beim Laden der Session', 'danger');
    } finally {
        hideLoading();
    }
}

async function renderSessionDetail(session) {
    // Session Info
    document.getElementById('session-info').innerHTML = `
        <div class="row">
            <div class="col-md-6">
                <p><strong>Hund:</strong> ${escapeHtml(session.dog_name)}</p>
                <p><strong>Rasse:</strong> ${escapeHtml(session.breed || '-')}</p>
                <p><strong>Halter:</strong> ${escapeHtml(session.owner_name)}</p>
            </div>
            <div class="col-md-6">
                <p><strong>Testbatterie:</strong> ${escapeHtml(session.battery_name)}</p>
                <p><strong>Datum:</strong> ${formatDate(session.session_date)}</p>
                <p><strong>Einsatzgebiet:</strong> ${escapeHtml(session.intended_use || '-')}</p>
            </div>
        </div>
    `;

    // Session Notes
    document.getElementById('session-notes').value = session.session_notes || '';

    // Load battery tests and render table
    try {
        const battery = await api.getBattery(session.battery_id);
        state.currentBattery = battery;
        renderTestsTable(battery.tests, session.results || []);
        
        // Update progress
        const completedTests = (session.results || []).filter(r => r.score !== null).length;
        document.getElementById('test-progress').textContent = `${completedTests} / ${battery.tests.length}`;
    } catch (error) {
        console.error('Error loading battery:', error);
        renderTestsPlaceholder();
    }
}

function renderTestsTable(tests, results) {
    const tbody = document.getElementById('tests-tbody');
    
    // Create results map for quick lookup
    const resultsMap = {};
    results.forEach(r => {
        resultsMap[r.test_number] = r;
    });
    
    tbody.innerHTML = tests.map(test => {
        const result = resultsMap[test.test_number] || {};
        const currentScore = result.score ?? null;
        const currentNotes = result.notes || '';
        
        return `
            <tr data-test-number="${test.test_number}">
                <td class="text-center fw-bold">${test.test_number}</td>
                <td>${escapeHtml(test.test_name)}</td>
                <td class="text-center">
                    <span class="badge bg-${getOceanColor(test.ocean_dimension)}">
                        ${escapeHtml(test.ocean_dimension)}
                    </span>
                </td>
                <td class="text-center">
                    <div class="btn-group" role="group">
                        ${[-2, -1, 0, 1, 2].map(score => `
                            <button type="button" 
                                    class="btn btn-sm score-btn ${currentScore === score ? 'btn-primary active' : 'btn-outline-primary'}"
                                    onclick="setTestScore(${test.test_number}, ${score}, ${test.max_value})"
                                    data-score="${score}">
                                ${score > 0 ? '+' : ''}${score}
                            </button>
                        `).join('')}
                    </div>
                </td>
                <td>
                    <input type="text" 
                           class="form-control form-control-sm test-notes" 
                           placeholder="Notizen..."
                           value="${escapeHtml(currentNotes)}"
                           onchange="updateTestNotes(${test.test_number}, this.value)">
                </td>
            </tr>
        `;
    }).join('');
}

function renderTestsPlaceholder() {
    const tbody = document.getElementById('tests-tbody');
    tbody.innerHTML = `
        <tr>
            <td colspan="5" class="text-center text-muted py-4">
                <i class="bi bi-info-circle"></i> Testbatterie konnte nicht geladen werden.
            </td>
        </tr>
    `;
}

function getOceanColor(dimension) {
    const colors = {
        'Offenheit': 'primary',
        'Gewissenhaftigkeit': 'success',
        'Extraversion': 'warning',
        'Verträglichkeit': 'info',
        'Neurotizismus': 'danger'
    };
    return colors[dimension] || 'secondary';
}

async function setTestScore(testNumber, score, maxValue) {
    if (!state.currentSession) {
        showToast('Keine Session geladen', 'danger');
        return;
    }
    
    // Normierung auf max_value
    const normalizedScore = Math.round((score / 2) * maxValue);
    
    try {
        await api.saveResult({
            session_id: state.currentSession.session_id,
            test_number: testNumber,
            score: normalizedScore,
            notes: document.querySelector(`tr[data-test-number="${testNumber}"] .test-notes`).value
        });
        
        // UI Update
        const row = document.querySelector(`tr[data-test-number="${testNumber}"]`);
        row.querySelectorAll('.score-btn').forEach(btn => {
            const btnScore = parseInt(btn.dataset.score);
            if (btnScore === score) {
                btn.classList.remove('btn-outline-primary');
                btn.classList.add('btn-primary', 'active');
            } else {
                btn.classList.remove('btn-primary', 'active');
                btn.classList.add('btn-outline-primary');
            }
        });
        
        // Update progress
        await updateTestProgress();
        
    } catch (error) {
        showToast('Fehler beim Speichern: ' + error.message, 'danger');
    }
}

async function updateTestNotes(testNumber, notes) {
    if (!state.currentSession) return;
    
    try {
        // Get current score
        const row = document.querySelector(`tr[data-test-number="${testNumber}"]`);
        const activeBtn = row.querySelector('.score-btn.active');
        const score = activeBtn ? parseInt(activeBtn.dataset.score) : null;
        
        if (score !== null) {
            // Get max_value from battery
            const test = state.currentBattery.tests.find(t => t.test_number === testNumber);
            const normalizedScore = Math.round((score / 2) * test.max_value);
            
            await api.saveResult({
                session_id: state.currentSession.session_id,
                test_number: testNumber,
                score: normalizedScore,
                notes: notes
            });
        }
    } catch (error) {
        console.error('Error updating notes:', error);
    }
}

async function updateTestProgress() {
    try {
        const session = await api.getSession(state.currentSession.session_id);
        const completedTests = (session.results || []).filter(r => r.score !== null).length;
        const totalTests = state.currentBattery.tests.length;
        document.getElementById('test-progress').textContent = `${completedTests} / ${totalTests}`;
    } catch (error) {
        console.error('Error updating progress:', error);
    }
}

async function saveSession() {
    const sessionData = {
        session_notes: document.getElementById('session-notes').value
    };

    showLoading();
    try {
        await api.updateSession(state.currentSession.session_id, sessionData);
        showToast('Session gespeichert', 'success');
    } catch (error) {
        showToast(error.message, 'danger');
    } finally {
        hideLoading();
    }
}

// ===== BATTERIES =====
async function loadBatteriesList() {
    showLoading();
    try {
        const data = await api.getBatteries();
        state.batteries = data.batteries;
        renderBatteriesList(data.batteries);
    } catch (error) {
        showToast('Fehler beim Laden der Batterien', 'danger');
    } finally {
        hideLoading();
    }
}

function renderBatteriesList(batteries) {
    const container = document.getElementById('batteries-list');
    
    if (batteries.length === 0) {
        container.innerHTML = `
            <div class="alert alert-info">
                <i class="bi bi-info-circle"></i> Noch keine Testbatterien vorhanden. Importieren Sie eine Excel-Datei oder laden Sie das Template herunter.
            </div>
        `;
        return;
    }
    
    container.innerHTML = `
        <div class="table-responsive">
            <table class="table table-hover">
                <thead>
                    <tr>
                        <th>Name</th>
                        <th>Beschreibung</th>
                        <th class="text-center">Anzahl Tests</th>
                        <th class="text-center">Erstellt am</th>
                        <th class="text-end">Aktionen</th>
                    </tr>
                </thead>
                <tbody>
                    ${batteries.map(battery => `
                        <tr>
                            <td>
                                <strong>${escapeHtml(battery.name)}</strong>
                            </td>
                            <td>${escapeHtml(battery.description || '-')}</td>
                            <td class="text-center">
                                <span class="badge bg-primary">${battery.test_count} Tests</span>
                            </td>
                            <td class="text-center">
                                <small>${formatDate(battery.created_at)}</small>
                            </td>
                            <td class="text-end">
                                <div class="btn-group btn-group-sm">
                                    <button class="btn btn-outline-info" onclick="viewBatteryDetails(${battery.id})" title="Details anzeigen">
                                        <i class="bi bi-eye"></i>
                                    </button>
                                    <button class="btn btn-outline-danger" onclick="deleteBatteryConfirm(${battery.id}, '${escapeHtml(battery.name)}')" title="Löschen">
                                        <i class="bi bi-trash"></i>
                                    </button>
                                </div>
                            </td>
                        </tr>
                    `).join('')}
                </tbody>
            </table>
        </div>
    `;
}

async function viewBatteryDetails(id) {
    showLoading();
    try {
        const battery = await api.getBattery(id);
        
        // Modal erstellen
        const modal = document.createElement('div');
        modal.className = 'modal fade';
        modal.innerHTML = `
            <div class="modal-dialog modal-xl">
                <div class="modal-content">
                    <div class="modal-header">
                        <h5 class="modal-title">${escapeHtml(battery.name)}</h5>
                        <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                    </div>
                    <div class="modal-body">
                        ${battery.description ? `<p class="lead">${escapeHtml(battery.description)}</p>` : ''}
                        <h6 class="mt-3">Tests (${battery.tests.length})</h6>
                        <div class="table-responsive">
                            <table class="table table-sm table-striped">
                                <thead>
                                    <tr>
                                        <th>Nr.</th>
                                        <th>Testname</th>
                                        <th>OCEAN Dimension</th>
                                        <th class="text-end">Max. Wert</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    ${battery.tests.map(test => `
                                        <tr>
                                            <td>${test.test_number}</td>
                                            <td>${escapeHtml(test.test_name)}</td>
                                            <td>
                                                <span class="badge bg-${getOceanColor(test.ocean_dimension)}">
                                                    ${escapeHtml(test.ocean_dimension)}
                                                </span>
                                            </td>
                                            <td class="text-end">${test.max_value}</td>
                                        </tr>
                                    `).join('')}
                                </tbody>
                            </table>
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Schließen</button>
                    </div>
                </div>
            </div>
        `;
        
        document.body.appendChild(modal);
        const bsModal = new bootstrap.Modal(modal);
        
        modal.addEventListener('hidden.bs.modal', () => {
            modal.remove();
        });
        
        bsModal.show();
    } catch (error) {
        showToast('Fehler beim Laden der Batterie-Details', 'danger');
    } finally {
        hideLoading();
    }
}

async function deleteBatteryConfirm(id, name) {
    if (!confirm(`Testbatterie "${name}" wirklich löschen?\n\nACHTUNG: Dies ist nur möglich, wenn keine Sessions diese Batterie verwenden!`)) {
        return;
    }
    
    showLoading();
    try {
        await api.deleteBattery(id);
        showToast('Batterie gelöscht', 'success');
        await loadBatteriesList();
    } catch (error) {
        showToast(error.message, 'danger');
    } finally {
        hideLoading();
    }
}

function downloadTemplate() {
    api.downloadTemplate();
    showToast('Template wird heruntergeladen...', 'info');
}

async function uploadBattery() {
    const fileInput = document.getElementById('battery-file');
    
    if (!fileInput.files || fileInput.files.length === 0) {
        showToast('Bitte wählen Sie eine Excel-Datei aus', 'warning');
        return;
    }
    
    const file = fileInput.files[0];
    
    // Client-seitige Validierung
    const allowedExtensions = ['xlsx', 'xls'];
    const fileExtension = file.name.split('.').pop().toLowerCase();
    
    if (!allowedExtensions.includes(fileExtension)) {
        showToast('Ungültiges Dateiformat. Nur .xlsx und .xls erlaubt.', 'danger');
        return;
    }
    
    if (file.size > 5 * 1024 * 1024) {
        showToast('Datei zu groß. Maximum 5 MB.', 'danger');
        return;
    }
    
    showLoading();
    try {
        const result = await api.uploadBattery(file);
        
        showToast(
            `Batterie "${result.battery_name}" mit ${result.test_count} Tests erfolgreich importiert!`,
            'success'
        );
        
        // Batterien-Liste neu laden
        await loadBatteriesList();
        
        // Input leeren
        fileInput.value = '';
        
    } catch (error) {
        showToast('Import fehlgeschlagen: ' + error.message, 'danger');
    } finally {
        hideLoading();
    }
}

// ===== ANALYSIS =====
async function loadAnalysisSessionList() {
    showLoading();
    try {
        const data = await api.getSessions();
        const select = document.getElementById('select-analysis-session');
        
        select.innerHTML = '<option value="">-- Bitte Session auswählen --</option>';
        data.sessions.forEach(session => {
            const option = document.createElement('option');
            option.value = session.session_id;
            option.textContent = `${session.dog_name} - ${session.battery_name} (${formatDate(session.session_date)})`;
            select.appendChild(option);
        });
    } catch (error) {
        showToast('Fehler beim Laden der Sessions', 'danger');
    } finally {
        hideLoading();
    }
}

async function loadAnalysis(e) {
    const sessionId = e.target.value;
    
    if (!sessionId) {
        document.getElementById('analysis-container').classList.add('d-none');
        return;
    }

    showLoading();
    try {
        const oceanData = await api.getOceanScores(sessionId);
        const session = await api.getSession(sessionId);
        
        state.currentSession = session;
        
        renderOceanChart(oceanData);
        renderOceanStats(oceanData);
        
        // Owner Profile
        if (session.owner_profile) {
            document.getElementById('owner-o').value = session.owner_profile.O;
            document.getElementById('owner-c').value = session.owner_profile.C;
            document.getElementById('owner-e').value = session.owner_profile.E;
            document.getElementById('owner-a').value = session.owner_profile.A;
            document.getElementById('owner-n').value = session.owner_profile.N;
        }
        
        // AI Assessment
        if (session.ai_assessment) {
            document.getElementById('ai-assessment-content').innerHTML = `
                <div class="alert alert-success">
                    ${escapeHtml(session.ai_assessment).replace(/\n/g, '<br>')}
                </div>
            `;
        }
        
        document.getElementById('analysis-container').classList.remove('d-none');
    } catch (error) {
        showToast('Fehler beim Laden der Analyse', 'danger');
    } finally {
        hideLoading();
    }
}

function renderOceanStats(oceanData) {
    const container = document.getElementById('ocean-stats');
    
    const dimensions = [
        { key: 'O', name: 'Openness (Offenheit)' },
        { key: 'C', name: 'Conscientiousness (Gewissenhaftigkeit)' },
        { key: 'E', name: 'Extraversion (Extraversion)' },
        { key: 'A', name: 'Agreeableness (Verträglichkeit)' },
        { key: 'N', name: 'Neuroticism (Neurotizismus)' }
    ];
    
    container.innerHTML = `
        <table class="table table-hover">
            <thead>
                <tr>
                    <th>Dimension</th>
                    <th class="text-end">Summe</th>
                    <th class="text-end">Anzahl Tests</th>
                    <th class="text-end">Durchschnitt</th>
                </tr>
            </thead>
            <tbody>
                ${dimensions.map(dim => `
                    <tr>
                        <td><strong>${dim.name}</strong></td>
                        <td class="text-end">${oceanData.ocean_scores[dim.key]}</td>
                        <td class="text-end">${oceanData.test_counts[dim.key]}</td>
                        <td class="text-end">${oceanData.averages[dim.key].toFixed(2)}</td>
                    </tr>
                `).join('')}
            </tbody>
            <tfoot>
                <tr class="table-active">
                    <td><strong>Gesamt</strong></td>
                    <td class="text-end" colspan="2"><strong>${oceanData.total_completed_tests} Tests</strong></td>
                    <td></td>
                </tr>
            </tfoot>
        </table>
    `;
}

async function generateIdealProfile() {
    if (!state.currentSession) {
        showToast('Bitte Session auswählen', 'warning');
        return;
    }

    const session = state.currentSession;
    
    showLoading();
    try {
        const data = await api.generateIdealProfile({
            breed: session.breed || 'Mischling',
            age_years: session.age_years,
            age_months: session.age_months,
            gender: session.gender,
            intended_use: session.intended_use || 'Familienhund',
            test_count: 7
        });

        // Update session with ideal profile
        await api.updateSession(session.session_id, {
            ideal_profile: data.ideal_profile
        });

        showToast('Idealprofil generiert', 'success');
        
        // Reload chart
        loadAnalysis({ target: { value: session.session_id } });
    } catch (error) {
        showToast(error.message, 'danger');
    } finally {
        hideLoading();
    }
}

async function saveOwnerProfile() {
    if (!state.currentSession) {
        showToast('Bitte Session auswählen', 'warning');
        return;
    }

    const ownerProfile = {
        O: parseInt(document.getElementById('owner-o').value),
        C: parseInt(document.getElementById('owner-c').value),
        E: parseInt(document.getElementById('owner-e').value),
        A: parseInt(document.getElementById('owner-a').value),
        N: parseInt(document.getElementById('owner-n').value)
    };

    showLoading();
    try {
        await api.updateSession(state.currentSession.session_id, {
            owner_profile: ownerProfile
        });

        showToast('Halter-Profil gespeichert', 'success');
        
        // Reload chart
        loadAnalysis({ target: { value: state.currentSession.session_id } });
    } catch (error) {
        showToast(error.message, 'danger');
    } finally {
        hideLoading();
    }
}

async function generateAssessment() {
    if (!state.currentSession) {
        showToast('Bitte Session auswählen', 'warning');
        return;
    }

    showLoading();
    try {
        const oceanData = await api.getOceanScores(state.currentSession.session_id);
        const session = state.currentSession;

        if (!oceanData.profiles.ideal) {
            showToast('Bitte erst Idealprofil generieren', 'warning');
            hideLoading();
            return;
        }

        const assessmentData = {
            ist_profile: oceanData.ocean_scores,
            ideal_profile: oceanData.profiles.ideal,
            owner_profile: oceanData.profiles.owner,
            dog_data: {
                dog_name: session.dog_name,
                breed: session.breed || 'Mischling',
                intended_use: session.intended_use || 'Familienhund'
            }
        };

        const data = await api.generateAssessment(assessmentData);

        // Save to session
        await api.updateSession(session.session_id, {
            ai_assessment: data.ai_assessment
        });

        document.getElementById('ai-assessment-content').innerHTML = `
            <div class="alert alert-success">
                ${escapeHtml(data.ai_assessment).replace(/\n/g, '<br>')}
            </div>
        `;

        showToast('KI-Bewertung generiert', 'success');
    } catch (error) {
        showToast(error.message, 'danger');
    } finally {
        hideLoading();
    }
}

// ===== UTILITY FUNCTIONS =====
function showLoading() {
    document.getElementById('loading-overlay').classList.remove('d-none');
}

function hideLoading() {
    document.getElementById('loading-overlay').classList.add('d-none');
}

function showToast(message, type = 'info') {
    const container = document.getElementById('toast-container');
    const id = `toast-${Date.now()}`;
    
    const toast = document.createElement('div');
    toast.className = `toast align-items-center text-white bg-${type} border-0`;
    toast.id = id;
    toast.setAttribute('role', 'alert');
    toast.innerHTML = `
        <div class="d-flex">
            <div class="toast-body">${escapeHtml(message)}</div>
            <button type="button" class="btn-close btn-close-white me-2 m-auto" data-bs-dismiss="toast"></button>
        </div>
    `;
    
    container.appendChild(toast);
    const bsToast = new bootstrap.Toast(toast);
    bsToast.show();
    
    toast.addEventListener('hidden.bs.toast', () => {
        toast.remove();
    });
}

function escapeHtml(text) {
    const div = document.createElement('div');
    div.textContent = text;
    return div.innerHTML;
}

function formatAge(years, months) {
    if (years === 0) return `${months} Monat${months !== 1 ? 'e' : ''}`;
    if (months === 0) return `${years} Jahr${years !== 1 ? 'e' : ''}`;
    return `${years}J ${months}M`;
}

function formatDate(dateString) {
    const date = new Date(dateString);
    return date.toLocaleDateString('de-DE', {
        year: 'numeric',
        month: '2-digit',
        day: '2-digit',
        hour: '2-digit',
        minute: '2-digit'
    });
}

function debounce(func, wait) {
    let timeout;
    return function executedFunction(...args) {
        const later = () => {
            clearTimeout(timeout);
            func(...args);
        };
        clearTimeout(timeout);
        timeout = setTimeout(later, wait);
    };
}
